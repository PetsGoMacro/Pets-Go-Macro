Before you run MainMacro make sure you edit it to your auto clicker's hotkey 

This is selected by autoclickerkey.

I havent made it to work automatically.

Or just set your auto Clicker's hotkey to NumPadSub
